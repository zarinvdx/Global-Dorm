package globaldorm;

import globaldorm.ApplicationService;
import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/applicationHistory")
public class ApplicationHistoryServlet extends HttpServlet {

    private final ApplicationService applicationService = new ApplicationService();
    private static final String APPLICATIONS_FILE = "C:/Users/zarin/OneDrive - Nottingham Trent University/SCC/GlobalDorm/web/WEB-INF/applications.json";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String userEmail = request.getParameter("userEmail");
        response.setContentType("application/json");
        

        if (userEmail == null || userEmail.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"User email is required.\"}");
            return;
        }

        try {
            JSONArray applications = applicationService.getApplicationHistory(userEmail);
            JSONArray filteredApplications = new JSONArray();

            for (int i = 0; i < applications.length(); i++) {
                JSONObject app = applications.getJSONObject(i);

           
                if (userEmail.equalsIgnoreCase(app.optString("userEmail", ""))) {
                    JSONObject filteredApp = new JSONObject();
                    filteredApp.put("applicationId", app.optInt("applicationId", -1));
                    filteredApp.put("roomId", app.optString("roomId", "N/A"));
                    filteredApp.put("status", app.optString("status", "Unknown"));
                    filteredApplications.put(filteredApp);
                }
            }

            if (filteredApplications.length() > 0) {
                response.getWriter().write(filteredApplications.toString(4)); 
            } else {
                response.getWriter().write("{\"message\": \"No applications found for this user.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"An error occurred while retrieving application history.\"}");
        }
    }
}
