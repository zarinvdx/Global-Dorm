package globaldorm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherService {
    public static String getWeather(String latitude, String longitude) {
        try {
            String apiUrl = String.format(
                "https://www.7timer.info/bin/civillight.php?lon=%s&lat=%s&output=json",
                longitude, latitude
            );

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            return response.toString(); 
        } catch (Exception e) {
            e.printStackTrace();
            return "Error fetching weather data.";
        }
    }
}
