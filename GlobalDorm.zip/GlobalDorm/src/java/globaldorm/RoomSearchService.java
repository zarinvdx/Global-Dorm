package globaldorm;

import java.io.BufferedReader;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class RoomSearchService {

    private static final String ROOMS_JSON_FILE = "C:/Users/zarin/OneDrive - Nottingham Trent University/SCC/GlobalDorm/web/WEB-INF/rooms.json";

    public boolean accommodationPostcodeExists(String postcode) {
        try {
            JSONArray rooms = getRooms(); 
            for (int i = 0; i < rooms.length(); i++) {
                JSONObject room = rooms.getJSONObject(i);
                String roomPostcode = room.getJSONObject("location").getString("postcode");
                if (roomPostcode.equalsIgnoreCase(postcode.trim())) {
                    return true;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }


    public JSONArray getRooms() throws IOException {
        File file = new File(ROOMS_JSON_FILE);
        System.out.println("File path: " + file.getAbsolutePath());

        if (!file.exists()) {
            throw new IOException("Rooms file not found: " + file.getAbsolutePath());
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            StringBuilder jsonData = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonData.append(line);
            }
            return new JSONObject(jsonData.toString()).getJSONArray("rooms");
        }
    }


    public JSONArray searchRoomsByKeyword(String keyword) throws IOException {
        JSONArray rooms = getRooms();
        JSONArray filteredRooms = new JSONArray();

        for (int i = 0; i < rooms.length(); i++) {
            JSONObject room = rooms.getJSONObject(i);
            if (room.getString("name").toLowerCase().contains(keyword.toLowerCase())
                    || room.getJSONObject("location").getString("city").toLowerCase().contains(keyword.toLowerCase())) {
                filteredRooms.put(room);
            }
        }

        System.out.println("Filtered Rooms for keyword '" + keyword + "': " + filteredRooms.length()); 
        return filteredRooms;
    }

}