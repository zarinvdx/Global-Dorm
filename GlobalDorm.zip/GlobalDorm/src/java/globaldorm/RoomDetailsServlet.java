package globaldorm;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/roomDetails")
public class RoomDetailsServlet extends HttpServlet {

    private final RoomSearchService roomSearchService = new RoomSearchService();
    private static final String ROOMS_FILE = "C:/Users/zarin/OneDrive - Nottingham Trent University/SCC/GlobalDorm/web/WEB-INF/rooms.json";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String roomId = request.getParameter("id");
        response.setContentType("application/json");

        if (roomId == null || roomId.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Room ID is required.\"}");
            return;
        }

        try {
            JSONArray rooms = roomSearchService.getRooms(); 
            for (int i = 0; i < rooms.length(); i++) {
                JSONObject room = rooms.getJSONObject(i);
                if (room.getInt("id") == Integer.parseInt(roomId)) {
                    response.getWriter().write(room.toString(4)); 
                    return;
                }
            }
            response.setStatus(HttpServletResponse.SC_NOT_FOUND);
            response.getWriter().write("{\"error\": \"Room not found.\"}");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"An error occurred while fetching room details.\"}");
        }
    }
}

