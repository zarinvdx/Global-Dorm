package globaldorm;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/weather")
public class WeatherServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String postcode = request.getParameter("postcode");
        String coordinates = DistanceService.getCoordinates(postcode);

        if (coordinates.startsWith("Error")) {
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"" + coordinates + "\"}");
            return;
        }

        String[] latLong = coordinates.split(",");
        String weatherData = WeatherService.getWeather(latLong[0], latLong[1]);

        response.setContentType("application/json");
        response.getWriter().write(weatherData);
    }
}
