package globaldorm;

import java.io.IOException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import globaldorm.ApplicationService;

@WebServlet("/applications")

public class ApplicationServlet extends HttpServlet {

    private final ApplicationService applicationService = new ApplicationService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");

        String action = request.getParameter("action");
        String applicationId = request.getParameter("applicationId");
        String userEmail = request.getParameter("userEmail");
        String roomId = request.getParameter("roomId");
        String userName = request.getParameter("userName");

        if (action == null || action.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Action parameter is required.\"}");
            return;
        }

        try {
            switch (action.toLowerCase()) {
                case "apply":
                    handleApplyForRoom(response, roomId, userName, userEmail);
                    break;
                case "viewhistory":
                    handleViewHistory(response, userEmail);
                    break;
                case "cancel":
                    handleCancelApplication(response, applicationId);
                    break;
                default:
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    response.getWriter().write("{\"error\": \"Invalid action.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"An error occurred while processing the request.\"}");
        }
    }

    private void handleApplyForRoom(HttpServletResponse response, String roomId, String userName, String userEmail) throws IOException {
        if (roomId == null || userName == null || userEmail == null
                || roomId.trim().isEmpty() || userName.trim().isEmpty() || userEmail.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Missing required parameters.\"}");
            return;
        }

        try {
           
            JSONArray existingApplications = applicationService.getApplicationHistory(userEmail);
            for (int i = 0; i < existingApplications.length(); i++) {
                JSONObject app = existingApplications.getJSONObject(i);
                if (app.getInt("roomId") == Integer.parseInt(roomId) && "pending".equalsIgnoreCase(app.getString("status"))) {
                    response.getWriter().write("{\"message\": \"You already have a pending application for this room.\"}");
                    return;
                }
            }

         
            JSONObject newApplication = new JSONObject();
            newApplication.put("roomId", Integer.parseInt(roomId));
            newApplication.put("userName", userName);
            newApplication.put("userEmail", userEmail);
            newApplication.put("status", "pending");

            boolean success = applicationService.addApplication(newApplication);
            if (success) {
                response.getWriter().write("{\"message\": \"Application submitted successfully.\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"error\": \"Failed to save the application.\"}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Invalid room ID.\"}");
        }
    }

    private void handleViewHistory(HttpServletResponse response, String userEmail) throws IOException {
        if (userEmail == null || userEmail.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"User email is required.\"}");
            return;
        }

        try {
            JSONArray history = applicationService.getApplicationHistory(userEmail);

            if (history.length() > 0) {
                response.getWriter().write(history.toString(4));
            } else {
                response.getWriter().write("{\"message\": \"No applications found for this user.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"An error occurred while retrieving application history.\"}");
        }
    }

    private void handleCancelApplication(HttpServletResponse response, String applicationId) throws IOException {
        if (applicationId == null || applicationId.trim().isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Application ID is required.\"}");
            return;
        }

        try {
            boolean success = applicationService.cancelApplicationById(Integer.parseInt(applicationId));
            if (success) {
                response.getWriter().write("{\"message\": \"Application cancelled successfully.\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("{\"error\": \"Application ID not found.\"}");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Invalid Application ID.\"}");
        }
    }

}
