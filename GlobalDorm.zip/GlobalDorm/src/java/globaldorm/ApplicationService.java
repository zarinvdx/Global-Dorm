package globaldorm;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;

public class ApplicationService {

    private static final String APPLICATIONS_FILE = "C:/Users/zarin/OneDrive - Nottingham Trent University/SCC/GlobalDorm/web/WEB-INF/applications.json";

   
    public boolean addApplication(JSONObject application) {
        try {
            JSONObject data = readJsonFile(APPLICATIONS_FILE);
            JSONArray applications = data.optJSONArray("applications");
            if (applications == null) {
                applications = new JSONArray();
                data.put("applications", applications);
            }

        
            int maxId = 0;
            for (int i = 0; i < applications.length(); i++) {
                JSONObject app = applications.getJSONObject(i);
                if (app.has("applicationId")) {
                    maxId = Math.max(maxId, app.getInt("applicationId"));
                }
            }
            application.put("applicationId", maxId + 1);

            applications.put(application);
            writeJsonFile(APPLICATIONS_FILE, data);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    public boolean cancelApplicationById(int applicationId) {
    try {
        JSONObject data = readJsonFile(APPLICATIONS_FILE);
        JSONArray applications = data.optJSONArray("applications");
        if (applications != null) {
            for (int i = 0; i < applications.length(); i++) {
                JSONObject app = applications.getJSONObject(i);
                if (app.optInt("applicationId", -1) == applicationId) { 
                    app.put("status", "canceled");
                    writeJsonFile(APPLICATIONS_FILE, data);
                    return true;
                }
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return false;
}


    public JSONArray getApplicationHistory(String userEmail) {
        JSONArray history = new JSONArray();
        try {
            JSONObject data = readJsonFile(APPLICATIONS_FILE);
            JSONArray applications = data.optJSONArray("applications");
            if (applications != null) {
                for (int i = 0; i < applications.length(); i++) {
                    JSONObject app = applications.getJSONObject(i);
                    if (app.has("userEmail") && app.getString("userEmail").equalsIgnoreCase(userEmail)) {
                        history.put(app);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return history;
    }


    private JSONObject readJsonFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder jsonData = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                jsonData.append(line);
            }
            return new JSONObject(jsonData.toString());
        } catch (Exception e) {
            e.printStackTrace();
            return new JSONObject();
        }
    }


    private void writeJsonFile(String filePath, JSONObject data) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(data.toString(4)); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
