package globaldorm;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

public class DistanceService {

    private static final double EARTH_RADIUS_KM = 6371; 

    public static String getCoordinates(String postcode) {
        try {
            String apiUrl = String.format("https://api.postcodes.io/postcodes/%s", postcode);
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.getInt("status") == 200) {
                JSONObject result = jsonResponse.getJSONObject("result");
                return result.getDouble("latitude") + "," + result.getDouble("longitude");
            } else {
                System.err.println("Error fetching coordinates for postcode: " + postcode);
                return "Error";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error";
        }
    }

    public static String calculateDistanceOSRM(String startCoordinates, String destinationCoordinates) {
        try {
            String apiUrl = String.format(
                    "http://router.project-osrm.org/route/v1/driving/%s;%s?overview=false",
                    startCoordinates, destinationCoordinates
            );

            System.out.println("OSRM API URL: " + apiUrl);

            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            System.out.println("OSRM API Response: " + response.toString());

            JSONObject jsonResponse = new JSONObject(response.toString());
            if (jsonResponse.has("routes") && jsonResponse.getJSONArray("routes").length() > 0) {
                double distance = jsonResponse.getJSONArray("routes")
                        .getJSONObject(0)
                        .getDouble("distance") / 1000; 
                if (distance > 0) {
                    return String.format("%.2f km", distance);
                } else {
                    System.err.println("OSRM API returned 0 distance.");
                    return "Distance data unavailable.";
                }
            } else {
                System.err.println("OSRM API returned no valid routes.");
                return "Distance data unavailable.";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Error fetching distance.";
        }
    }

    public static String calculateDistanceHaversine(String startCoordinates, String destinationCoordinates) {
        try {
            String[] start = startCoordinates.split(",");
            String[] destination = destinationCoordinates.split(",");

            double lat1 = Math.toRadians(Double.parseDouble(start[0]));
            double lon1 = Math.toRadians(Double.parseDouble(start[1]));
            double lat2 = Math.toRadians(Double.parseDouble(destination[0]));
            double lon2 = Math.toRadians(Double.parseDouble(destination[1]));

            double dLat = lat2 - lat1;
            double dLon = lon2 - lon1;

            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                    + Math.cos(lat1) * Math.cos(lat2)
                    * Math.sin(dLon / 2) * Math.sin(dLon / 2);

            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = EARTH_RADIUS_KM * c;

            return String.format("%.2f km", distance);
        } catch (Exception e) {
            e.printStackTrace();
            return "Error calculating distance.";
        }
    }
}
