package globaldorm;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/distance")
public class DistanceServlet extends HttpServlet {

    private final RoomSearchService roomSearchService = new RoomSearchService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String accommodationPostcode = request.getParameter("accommodationPostcode").trim();
        String userPostcode = request.getParameter("userPostcode").trim();

        response.setContentType("application/json");

        System.out.println("User provided accommodationPostcode: " + accommodationPostcode);
        System.out.println("User provided userPostcode: " + userPostcode);

        if (accommodationPostcode.isEmpty() || userPostcode.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("{\"error\": \"Both accommodation and user postcodes are required.\"}");
            return;
        }

        try {
       
            boolean postcodeExists = roomSearchService.accommodationPostcodeExists(accommodationPostcode);
            if (!postcodeExists) {
                System.out.println("Accommodation postcode not found: " + accommodationPostcode);
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"error\": \"Accommodation postcode not found in the database.\"}");
                return;
            }

            String accommodationCoordinates = DistanceService.getCoordinates(accommodationPostcode);
            String userCoordinates = DistanceService.getCoordinates(userPostcode);

            System.out.println("Accommodation Coordinates: " + accommodationCoordinates);
            System.out.println("User Coordinates: " + userCoordinates);

            if (!accommodationCoordinates.equals("Error") && !userCoordinates.equals("Error")) {
                String distance = DistanceService.calculateDistanceOSRM(accommodationCoordinates, userCoordinates);

                if (distance.equals("Error fetching distance.") || distance.equals("Distance data unavailable.")) {
                    System.out.println("OSRM API failed. Falling back to Haversine formula...");
                    distance = DistanceService.calculateDistanceHaversine(accommodationCoordinates, userCoordinates);
                }

                System.out.println("Final Calculated Distance: " + distance);
                response.getWriter().write(String.format("{\"distance\": \"%s\"}", distance));
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                response.getWriter().write("{\"error\": \"Invalid coordinates for one or both postcodes.\"}");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"An unexpected error occurred.\"}");
        }
    }
}
