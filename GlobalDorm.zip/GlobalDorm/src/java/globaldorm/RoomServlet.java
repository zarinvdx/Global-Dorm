package globaldorm;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/rooms")
public class RoomServlet extends HttpServlet {

    private final RoomSearchService roomSearchService = new RoomSearchService();
    private static final String ROOMS_JSON_FILE = "C:\\Users\\zarin\\OneDrive - Nottingham Trent University\\SCC\\GlobalDorm\\web\\WEB-INF\\rooms.json";


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("Received GET request for rooms.");
        System.out.println("Query Parameters: " + request.getQueryString());

        response.setContentType("application/json");

        try {
            JSONArray rooms;
            String searchQuery = request.getParameter("searchQuery");

            if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                System.out.println("Filtering rooms with query: " + searchQuery);
                rooms = roomSearchService.searchRoomsByKeyword(searchQuery);
            } else {
                System.out.println("Returning all rooms.");
                rooms = roomSearchService.getRooms();
            }

            System.out.println("Rooms found: " + rooms.length());
            response.getWriter().write(new JSONObject().put("rooms", rooms).toString());
        } catch (Exception e) {
            System.err.println("Error in /rooms: " + e.getMessage());
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("{\"error\": \"Internal server error\"}");
        }
    }
}
