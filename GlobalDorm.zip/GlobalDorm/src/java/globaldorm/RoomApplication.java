package globaldorm;

import org.json.JSONObject;

public class RoomApplication {
    private static int idCounter = 1; 
    private int applicationId;
    private int roomId;
    private String userName;
    private String userEmail;
    private String status;


    public RoomApplication(int roomId, String userName, String userEmail) {
        this.applicationId = idCounter++;
        this.roomId = roomId;
        this.userName = userName;
        this.userEmail = userEmail;
        this.status = "Pending";
    }


    public int getApplicationId() {
        return applicationId;
    }

    public int getRoomId() {
        return roomId;
    }

    public String getUserName() {
        return userName;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }


    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("applicationId", applicationId);
        json.put("roomId", roomId);
        json.put("userName", userName);
        json.put("userEmail", userEmail);
        json.put("status", status);
        return json;
    }
}